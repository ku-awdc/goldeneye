# goldeneye
Secure sharing of sensitive information using a combination of asymmetric and symmetric encryption methods
