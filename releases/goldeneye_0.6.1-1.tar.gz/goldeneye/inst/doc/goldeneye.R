## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(goldeneye_redact=TRUE)
unlink("goldeneye_private.gyp")
unlink("secret.rdg")
unlink("secret_for_md.rdg")
unlink("goldeneye_public.gyu")
unlink("gy_demo22_test_public.gyu")

## ----eval=FALSE---------------------------------------------------------------
#  install.packages('goldeneye', repos=c('https://cran.rstudio.com/',
#                                        'https://ku-awdc.github.io/drat/'))

## -----------------------------------------------------------------------------
library("goldeneye")

## ----eval=FALSE---------------------------------------------------------------
#  gy_setup()

## ----include=FALSE------------------------------------------------------------
keyring::key_set_with_value("goldeneye", "test@test.com", "test")
gy_setup(name = "Test User", email="test@test.com", filename="goldeneye_private.gyp", path=getwd(), append_Rprofile = FALSE)

## -----------------------------------------------------------------------------
secret <- "Some super secret data (this could be a data frame, a list, or any other R object)"
gy_save(secret, users="https://www.costmodds.org/people/matt/goldeneye_public.gyu",
        file="secret.rdg")

## -----------------------------------------------------------------------------
(gy_load("secret.rdg"))
secret

## -----------------------------------------------------------------------------
gy_public_file()

## -----------------------------------------------------------------------------
gy_join_group("https://www.costmodds.org/rsc/goldeneye/demo22.gyg#oHrjws1utM#md")

## -----------------------------------------------------------------------------
gy_users()

## -----------------------------------------------------------------------------
secret <- "don't tell anyone"
gy_save(secret, users=c("md"), file="secret_for_md.rdg")

## ----echo=FALSE---------------------------------------------------------------
options(goldeneye_redact=FALSE)
unlink("goldeneye_private.gyp")
unlink("secret.rdg")
unlink("secret_for_md.rdg")
unlink("goldeneye_public.gyu")
unlink("gy_demo22_test_public.gyu")

